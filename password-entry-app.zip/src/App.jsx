import './App.css';
import PasswordEntry from './components/PasswordEntry';

function App() {
  return (
    <div className="App">
      <PasswordEntry />
    </div>
  );
}

export default App;
