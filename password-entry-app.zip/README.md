# An app for the Password Entry Validation.

Please follow the below steps for the test.

- You should follow below commands in terminal for running this app.

### `npm install`

Install node modules for this app.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.